# health bar
start_v = 150
length = 150
direction = 'lr'
